<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_home extends CI_Model {
	
	function __construct(){

		parent::__construct();
	}
}
